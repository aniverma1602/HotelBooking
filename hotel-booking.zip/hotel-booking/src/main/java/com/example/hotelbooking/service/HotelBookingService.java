package com.example.hotelbooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hotelbooking.dao.HotelBooking;
import com.example.hotelbooking.repository.HotelBookingRepository;

@Service
public class HotelBookingService {
    @Autowired
    private HotelBookingRepository bookingRepository;

    public List<HotelBooking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public HotelBooking getBookingById(Long id) {
        return bookingRepository.findById(id).orElse(null);
    }

    public HotelBooking createBooking(HotelBooking booking) {
        return bookingRepository.save(booking);
    }

    public HotelBooking updateBooking(Long id, HotelBooking updatedBooking) {
        if (bookingRepository.existsById(id)) {
            updatedBooking.setId(id);
            return bookingRepository.save(updatedBooking);
        }
        return null;
    }

    public boolean deleteBooking(Long id) {
        if (bookingRepository.existsById(id)) {
            bookingRepository.deleteById(id);
            return true;
        }
        return false;
    }
}

